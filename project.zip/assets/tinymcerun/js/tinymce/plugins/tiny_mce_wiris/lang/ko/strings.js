var strings = new Array();
strings['cancel'] = '취소';
strings['accept'] = '승인';
strings['manual'] = '설명서';
strings['latex'] = 'LaTeX';